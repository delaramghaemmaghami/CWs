
from cabin.models import *


def query_1(x):
    q = 'your query here'
    return q


def query_2(x):
    q = 'your query here'
    return q


def query_3(x):
    q = 'your query here'
    return q


def query_4(x, y, r):
    q='your query here'
    return q


def query_5():
    q = 'your query here'
    return q



def query_6(c):
    q = 'your query here'
    return q
