DEBUG = True
DEVEL = True

DB_NAME = 'cabin_db'
DB_USER = 'root'
DB_PASS = 'l.hosnarokh'
DB_HOST = 'localhost'
MEDIA_URL = ''
BASE_URL = ''

ALLOWED_HOSTS = ['*']
