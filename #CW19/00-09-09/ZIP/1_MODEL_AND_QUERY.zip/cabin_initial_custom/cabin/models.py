from django.db import models

car_type_choices = (
    ('A', 'class A'),
    ('B', 'class B'),
    ('C', 'class C'),
)


class Account(models.Model):
	pass

class Admin(models.Model):
    	pass


class Rider(models.Model):
	pass


class Driver(models.Model):
	pass


class RideRequest(models.Model):
	pass


class Car(models.Model):
	pass


class Ride(models.Model):
	pass

class Payment(models.Model):
	pass	

