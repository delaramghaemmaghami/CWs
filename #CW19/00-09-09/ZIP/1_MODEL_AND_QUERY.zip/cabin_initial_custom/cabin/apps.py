from django.apps import AppConfig


class AirlineConfig(AppConfig):
    name = 'cabin'
