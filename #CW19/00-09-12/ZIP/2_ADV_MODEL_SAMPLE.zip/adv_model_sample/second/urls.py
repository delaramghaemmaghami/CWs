from django.urls import path
from .views import second_view
urlpatterns = [
    path('econd/', second_view),
]