from django.shortcuts import render
from .models import Person, Group, Membership
# Create your views here.
def second_view(req):
    re = Membership.objects.filter(person__name__startswith='h')
    print(re)

    p_all = Person.objects.all()
    p_all.filter(name__contain="a")
    p_all.filter(age=22)

    print(p_all)



    for p in p_all:
        print("* : ", p.membership_set.all())
        # for x in p.membership_set.filter(name__startswith='h'):
        for x in p.membership_set.filter(person_id__name__startswith='h'):
            print(x)
    print('----------')


    g_all = Group.objects.all()
    for g in g_all:
        print(g.membership_set.all())
    print('----------')


    # p_g_2 = Person.objects.filter(x='2')
    p_g_3 = Person.objects.filter(membership__group__name='3')
    print("p_g_3", p_g_3)
    

    return render(req, 'second/second.html')
    

