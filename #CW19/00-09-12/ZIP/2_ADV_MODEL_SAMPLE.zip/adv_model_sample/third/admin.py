from django.contrib import admin

from .models import Person, Group, MyClassName, HehClassSmile

admin.site.register(Person)
admin.site.register(Group)
admin.site.register(MyClassName)
admin.site.register(HehClassSmile)