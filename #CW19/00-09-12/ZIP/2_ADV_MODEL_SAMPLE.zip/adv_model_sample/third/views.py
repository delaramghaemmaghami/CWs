from django.shortcuts import render
from .models import Person, Group
from pprint import pprint
# Create your views here.
def third_view(req):
    print("third")
    p_all = Person.objects.get(name__contains='a')
    print("all persons")
    print(p_all)
    for p in p_all:
        # print("8 : ", p.group_set.all())
        for x in p.rel_per.all():
            print(x)
    print('----------')

    g_all = Group.objects.all()
    print("all groups")
    print(g_all)
    for g in g_all:
        print(g.members.all())
    print('----------')
    
    p_g_2 = Person.objects.filter(rel_q_per=2)
    print("p_g_2", p_g_2)
    # g_1_p = Group.objects.filter(x=1)

    return render(req, 'third/third.html')
    
