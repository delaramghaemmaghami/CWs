from django.urls import path
from .views import third_view

urlpatterns = [
    path('hird/', third_view),
]