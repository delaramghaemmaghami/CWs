from django.db import models

class Person(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self) -> str:
        return self.name

class Group(models.Model):
    name = models.CharField(max_length=128)
    members = models.ManyToManyField(
        Person, related_name="rel_per", related_query_name="rel_q_per"
    )
    def __str__(self) -> str:
        return self.name





from django.db import models

class Place(models.Model):
    name = models.CharField(max_length=50)
    address = models.CharField(max_length=80)

class Restaurant(Place):
    serves_hot_dogs = models.BooleanField(default=False)
    serves_pizza = models.BooleanField(default=False)




    

class MyClassName(models.Model):
    name = models.CharField(max_length=12)

class HehClassSmile(models.Model):
    name = models.CharField(max_length=12)
    class Meta:
        ordering = ['name']
        verbose_name = "SALAM "
        verbose_name_plural = "Bye"
        # verbose_name = "entry "
        # verbose_name_plural = "entries"

