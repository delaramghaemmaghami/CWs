from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Person)
admin.site.register(BlogPost)
admin.site.register(Manufacture)
admin.site.register(Manufacture1)
admin.site.register(Manufacture2)
admin.site.register(Car)
admin.site.register(Car1)
admin.site.register(Car2)
