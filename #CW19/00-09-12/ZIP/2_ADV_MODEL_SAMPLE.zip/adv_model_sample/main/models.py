from django.db import models
from django.core.validators import (MinValueValidator, 
                MaxValueValidator, MinLengthValidator)
from django.utils.text import slugify 

import os

from django.db.models.deletion import CASCADE, PROTECT, RESTRICT
# Create your models here.
class Person(models.Model):

    SHIRT_SIZE = [
        ('S', 'Small'),
        ('M', 'Medium'),
        ('L', 'Large')
    ]

    MALE = 'M'
    FEMALE = 'F'
    SEX = [
        (MALE, 'male'),
        (FEMALE, 'female')
    ]


    SEX = [
        ('M', 'male'),
        ('F', 'female')
    ]

    JUST_TEST = [
        (None, '---'),
        (0, 'A'),
        (1, 'B'),
        (2, 'C'),
        (3, 'D')
    ]

    def get_upload_path(self, filename):
        ext = filename.split('.')[-1] #jpg
        filename = '{}.{}'.format(str(self.id), ext) # 5.jpg
        path = f'avatar/persons/{self.id}'
        return os.path.join(path, filename)
        # avatar/persons/5/5.jpg

    f_name = models.CharField(db_column="first_name", verbose_name="the 1st name", max_length=50)
    l_name = models.CharField(max_length=50, help_text="enter your family")
    age = models.IntegerField(validators=[MinValueValidator(18), MaxValueValidator(65)])
    shirt_size = models.CharField(choices=SHIRT_SIZE, max_length=1,null=True, blank=True)
    sex = models.CharField(choices=SEX, max_length=1, default='F')
    just_test = models.IntegerField(editable=False, choices=JUST_TEST, default=2, null=True, blank=True)
    
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True, default=None)
    aks_2 = models.ImageField(upload_to='aks/%Y/%m/%d/', null=True, blank=True, default=None)
    aks = models.ImageField(upload_to='aks/%Y__%m__%d/', null=True, blank=True, default=None)
    avatar_id = models.ImageField(upload_to=get_upload_path, null=True, blank=True, default=None)
    # avatar_id = models.ImageField(upload_to=f'person/{self.id}', null=True, blank=True, default=None)
    
    slug = models.SlugField(unique=True,blank=True)

    class Meta:
        db_table = "my_person_tbl"

    def save(self, *args, **kwargs):
        if self.f_name and self.l_name:
            temp_slug = slugify(self.f_name+" "+self.l_name)
            re = Person.objects.filter(slug=temp_slug).exists()
            if re:
                last_id = Person.objects.latest('id').id + 1
                temp_slug = slugify(self.f_name+" "+self.l_name+"_"+str(last_id))
            self.slug = temp_slug
        super().save(*args, **kwargs)

    def __str__(self):
        return self.f_name+"**"+self.l_name






class BlogPost(models.Model):
    title = models.CharField(max_length=5, validators=[MinLengthValidator(3)])
    body = models.TextField(max_length=720)
    created_at = models.DateTimeField(auto_now_add=True)
    update_at = models.DateTimeField(auto_now=True)
    dur = models.DurationField()
    test = models.DateTimeField(null=True, blank=True, default=None)









class Manufacture(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Car(models.Model):
    manufac = models.ForeignKey(Manufacture, on_delete=CASCADE)
    name = models.CharField(max_length=50)
    car_model = models.CharField(max_length=50)

    def __str__(self):
        return self.name+ " " + self.car_model





class Manufacture1(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Car1(models.Model):
    manufac = models.ForeignKey(Manufacture1, on_delete=PROTECT)
    name = models.CharField(max_length=50)
    car_model = models.CharField(max_length=50)

    def __str__(self):
        return self.name + " " + self.car_model





class Manufacture2(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Car2(models.Model):
    manufac = models.ForeignKey(Manufacture2, on_delete=RESTRICT)
    name = models.CharField(max_length=50)
    car_model = models.CharField(max_length=50)

    def __str__(self):
        return self.name+ " " + self.car_model

