from django.shortcuts import render
from .models import Person
# Create your views here.
def show_persons(req):
    p = Person.objects.all()

    return render(req, 'persons.html', {'p':p})

def person_detail(req, slug):
    print(slug)
    p = Person.objects.get(slug=slug)
    return render(req, 'person_detail.html', {'p': p})

def person_detail_id(req, id):
    print(id)
    p = Person.objects.get(pk=id)
    return render(req, 'person_detail.html', {'p': p})