from django.urls import path, include
from .views import show_persons, person_detail, person_detail_id
urlpatterns = [
    path('persons/', show_persons, name="p_all"),
    path('persons/<int:id>/', person_detail_id, name="p_detail_i"),
    path('persons/<slug:slug>/', person_detail, name="p_detail"),
    
]