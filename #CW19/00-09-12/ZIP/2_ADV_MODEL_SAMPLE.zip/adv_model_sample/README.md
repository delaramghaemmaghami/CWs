------- Field options -------
null -> True , False
blank -> True , False
choices
db_column -> str
db_index -> True , False
default -> Any
editable -> True , False
help_text -> str
primary_key -> True , False
unique -> True , False
verbose_name -> str
validators -> list   from django.core.validators








------- Field Types -------
IntegerFiled    FloatFiled  DecimalField
BooleanFiled    NullBooleanFiled
CharFiled   TextFiled
DateFiled   TimeField   DateTimeField
EmailField URLField FileField ImageField

Foreignkey
ManyToManyField
OneToOneField

------- Field Lookups -------
https://docs.djangoproject.com/en/3.2/ref/models/querysets/
