from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Personnn)
admin.site.register(MyPersonnn)
admin.site.register(Artist)
admin.site.register(Album)
admin.site.register(Song)
