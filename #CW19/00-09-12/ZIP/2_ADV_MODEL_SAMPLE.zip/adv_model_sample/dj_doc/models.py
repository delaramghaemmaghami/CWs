from django.db import models

class Blog(models.Model):
    name = models.CharField(max_length=100)
    tagline = models.TextField()

    def __str__(self):
        return self.name

class Author(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField()

    def __str__(self):
        return self.name

class Entry(models.Model):
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE)
    headline = models.CharField(max_length=255)
    body_text = models.TextField()
    pub_date = models.DateField()
    mod_date = models.DateField()
    authors = models.ManyToManyField(Author)
    number_of_comments = models.IntegerField()
    number_of_pingbacks = models.IntegerField()
    rating = models.IntegerField()

    def __str__(self):
        return self.headline







class Artist(models.Model):
    name = models.CharField(max_length=10)

class Album(models.Model):
    artist = models.ForeignKey(Artist, on_delete=models.CASCADE)

class Song(models.Model):
    artist = models.ForeignKey(Artist, on_delete=models.CASCADE)
    album = models.ForeignKey(Album, on_delete=models.RESTRICT)

    




class Personnn(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    def __str__(self):
        return self.first_name

class MyPersonnn(Personnn):
    class Meta:
        proxy = True














































# import datetime


# class Student(models.Model):
#     diploma_choice = [("1", "diploma"),
#     ("2", "BA"), ("3", "MA"), ("4", "PHD"), ("5", "Others")]

#     f_name = models.CharField(db_column='first name', max_length=50)
#     l_name = models.CharField(db_column='last name', max_length=50, verbose_name="family name")
#     age = models.IntegerField(validators=[MinValueValidator(16), MaxValueValidator(60)])
#     national_code = models.CharField(db_index=True, max_length=10)
#     diploma = models.CharField(choices=diploma_choice, default="1", max_length=1, help_text="Enter that what is your diploma now.")
#     joined = models.DateTimeField(auto_now_add=True)
#     Last_Modified = models.DateTimeField(auto_now=True)
#     deadLine = models.DateField(null=True, default=datetime.date.today)
#     deadLine2 = models.TimeField(null=True, default=datetime.time)
#     deadLine2_1 = models.TimeField(null=True, default=datetime.datetime.now())
#     deadLine3 = models.DateTimeField(null=True, default=datetime.datetime.now())
#     deadLine4 = models.TimeField(null=True, default='10:33:45.01')
#     deadLine5 = models.DateTimeField(null=True, default='2021-11-26 11:31:16')
    
#     def __str__(self) :
#         return self.national_code