from django.shortcuts import render
from django.http import JsonResponse

from main.models import Person

# Create your views here.
def sample_json(req):
    print("yessssss")
    if req.method == 'POST':
        sam = req.POST
        #  = {
        #     'csrfmiddlewaretoken':CSRF_TOKEN,
        #     'text':input_data
        #     }

        # name = sam.get('text')
        # name = sam['text']

    json_response = {
        'students' : {
            0: {
                'name': 'raha',
                'age': 20,
                'group' : {
                    'name': ['yek','dow', 'seh']
                }
            },
            1: {
                'name': 'ava',
                'age': 21,
                'group' : {
                    'id' : 1,
                    'name': 'yek'
                }
            },
            2: {
                'name': 'baran',
                'age': 22,
                'group' : {
                    'id' : 2,
                    'name': 'dow'
                }
            }
        }
    }
    return JsonResponse(json_response)













def sample_json_from_db(req):
    print("yessssss")
    json_response = {'persons': {}}
    jr_p = json_response['persons']
    p_all = Person.objects.all()
    for p in p_all:
        print(p.group_set.all())
        print(type(p.group_set.all()))

        jr_p[p.id] = {
            'name': p.name,
            'age': p.age,
            'group': list(p.group_set.all().values_list('name',flat=True)),
        }
    print(json_response)
    print(type(json_response))
    return JsonResponse(json_response)




def sample_django_template(req):
    if req.method == 'POST'  and req.is_ajax():
        text = req.POST.get('text')
        
        p = Person.objects.filter(name__startswith=text)
        if p:
            return JsonResponse({
                'persons':list(p.values_list('name', flat=True))
            })
        else:
            return JsonResponse({
                'persons': [],
                'msg' : "doesn't match any files",
            })

    return render(req,'sample.html',{
        'test' : "test"
    })




























    # 'group': p.group_set.all().values('name'),
    # 'group': list(p.group_set.all().values('name')),
    # 'group': p.group_set.all().values_list('name', flat=True),
    # 'group': list(p.group_set.all().values_list('name', flat=True)),