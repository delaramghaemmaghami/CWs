from django.core.serializers.json import Serializer
from django.urls import path
from .views import *

urlpatterns = [
    path('', sample_json, name="json"),
    path('db/', sample_json_from_db, name="json_db"),
    path('db_temp/', sample_django_template, name="json_db_temp"),
]



