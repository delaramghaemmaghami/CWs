from django.urls import path, include
from .views import *

urlpatterns = [
    path('sample/', sampleOne.as_view()),


    path('persons/all/', PersonsView.as_view()),
    path('person/<int:pk>', PersonDetail.as_view()),


    path('groups/all/', GroupsView.as_view(), ),
    path('groups/<int:pk>', GroupDetail.as_view(), name="gh-detail"),

]
