
from django.contrib.auth.models import User 
from rest_framework.authtoken.models import Token 


from rest_framework import serializers
from .models import *


class GroupSerializers(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = '__all__' 
        # fields = ('name',)
        # fields = ['name']

class GroupSerializers2(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = ['name', "join_date"] 

class PersonSerializers(serializers.ModelSerializer):
    # created_by = UserSerializer()
    # group_set = GroupSerializers2(many=True, read_only=True, required=False)
    # groups = GroupSerializers2(many=True)
    # groups = serializers.StringRelatedField(many=True)
    # groups = serializers.PrimaryKeyRelatedField(queryset=Group.objects.all(),many=True)
    # groups = serializers.PrimaryKeyRelatedField(queryset=Group.objects.all(),many=True, read_only=True)
    groups = serializers.HyperlinkedRelatedField(
        many=True,
        read_only=True,
        view_name= "gh-detail"
    )
    class Meta :
        model = Person
        # fields = '__all__'
        # fields = ('name','age')
        # fields = ('name','age', 'group_set')
        fields = ('name','age', 'groups')
        






