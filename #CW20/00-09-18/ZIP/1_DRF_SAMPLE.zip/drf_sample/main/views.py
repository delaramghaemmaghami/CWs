from django.shortcuts import get_object_or_404
from rest_framework import status

from rest_framework.views import APIView
from rest_framework.response import Response

from .models import *
from .serializers import *



class sampleOne(APIView):
    def get(self, req, *args, **kwargs):
        return Response(
            {
            'salam': "salam be hame doustan"
            },
            status = status.HTTP_200_OK
        )



class PersonsView(APIView):
    
    def get(self,request,*args, **kwargs):
        # p  = Person.objects.get(id=1)
        p  = Person.objects.all() #queryset
        # serializer = PersonSerializers(p, many=True) #serializer(queryset)
        serializer = PersonSerializers(p,many=True,context={'request': request}) #for HyperlinkedRelatedField add context
        return Response({'persons':serializer.data}) # serializer(queryset).data

    def post(self, request, *args, **kwargs):
        serializer = PersonSerializers(data=request.data)
        if serializer.is_valid():
            serializer.save()
            # return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class PersonDetail(APIView):
    def get(self, request, pk):
        person = get_object_or_404(Person, pk=pk)
        # person = Person.objects.get(pk=10) # error
      
        data = PersonSerializers(person).data
        return Response(data)

        
class GroupsView(APIView):
    
    def get(self,request,*args, **kwargs):
        g  = Group.objects.all() 
        serializer = GroupSerializers(g, many=True)
        return Response({'groups':serializer.data})

    # def post(self, request, *args, **kwargs):
    #     serializer = GroupSerializers(data=request.data)
    #     if serializer.is_valid():
    #         serializer.save()
    #         # return Response(serializer.data, status=status.HTTP_201_CREATED)
    #         return Response({"status": "success", "data": serializer.data}, status=status.HTTP_201_CREATED)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class GroupDetail(APIView):
    def get(self, request, pk):
        g = get_object_or_404(Group, pk=pk)
        data = GroupSerializers(g).data
        return Response(data)

