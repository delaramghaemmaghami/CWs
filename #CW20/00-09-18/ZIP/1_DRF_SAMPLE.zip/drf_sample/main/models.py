from django.db import models

# Create your models here.
class Person(models.Model):
    LEVEL = [
        ('a', 'A'),
        ('b', 'B'),
        ('c', 'C'),
        ('d', 'D')
    ]
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    level = models.CharField(max_length=1,choices=LEVEL)

class Group(models.Model):
    name = models.CharField(max_length=50)
    person = models.ManyToManyField(Person, related_name="groups") # related_name = x
    join_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.name
