from django.db.models import fields
from rest_framework import serializers
from .models import *




class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = '__all__'



class PostSerializer(serializers.ModelSerializer):
    comment_set = CommentSerializer(many=True)
    class Meta:
        model = Post
        fields = ('body', 'title', 'created_at', 'comment_set')
