from django.shortcuts import render
from rest.models import Post
from rest_framework import generics
from .serializer import *


class PostsList(generics.ListAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer


class CommentsList(generics.ListAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


class PostsDetail(generics.RetrieveAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer



class CommentsDetail(generics.RetrieveAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


class PostsCommentsDetail(generics.ListAPIView):
    
    def get_queryset(self):
        queryset = Comment.objects.filter(post=self.kwargs['pk'])
        print(queryset)
        return queryset

    serializer_class = CommentSerializer
    
