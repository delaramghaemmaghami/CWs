from django.urls import path
from .views import *

urlpatterns = [
    path('post/all/', PostsList.as_view()),
    path('post/<int:pk>/', PostsDetail.as_view()),
    path('comment/all/', CommentsList.as_view()),
    path('comment/<int:pk>/', CommentsDetail.as_view()),
    path('post/<int:pk>/comment/', PostsCommentsDetail.as_view()),
]
